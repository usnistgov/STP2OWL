/* $Id */

/* Support for creating declarations and definitions from one statement */
/* This particular module ends definitions and declarations */

/* This software was developed by U.S. Government employees as part of
 * their official duties and is not subject to copyright.
 *
 * $Log
 */

#undef GLOBAL
#undef INITIALLY
#undef INITIALLY1
#undef INITIALLY2
#undef INITIALLY3
#undef INITIALLY4
#undef INITIALLY5
#undef INITIALLY6
#undef INITIALLY7
#undef INITIALLY8
#undef INITIALLY9
#undef INITIALLY10
#undef INITIALLY11
#undef INITIALLY12
