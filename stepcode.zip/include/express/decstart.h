/* $Id */

/* Support for creating declarations and definitions from one statement */
/* This particular module starts declarations */

/* This software was developed by U.S. Government employees as part of
 * their official duties and is not subject to copyright.
 *
 * $Log
 */

#define GLOBAL extern
#define INITIALLY(value)
#define INITIALLY1(a)
#define INITIALLY2(a,b)
#define INITIALLY3(a,b,c)
#define INITIALLY4(a,b,c,d)
#define INITIALLY5(a,b,c,d,e)
#define INITIALLY6(a,b,c,d,e,f)
#define INITIALLY7(a,b,c,d,e,f,g)
#define INITIALLY8(a,b,c,d,e,f,g,h)
#define INITIALLY9(a,b,c,d,e,f,g,h,i)
#define INITIALLY10(a,b,c,d,e,f,g,h,i,j)
#define INITIALLY11(a,b,c,d,e,f,g,h,i,j,k)
#define INITIALLY12(a,b,c,d,e,f,g,h,i,j,k,l)
