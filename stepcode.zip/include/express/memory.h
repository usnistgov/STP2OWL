#ifndef __MEMORY_H
#define __MEMORY_H

#include "sc_export.h"

SC_EXPRESS_EXPORT void MEMORYinitialize();

#endif // __MEMORY_H
