/*
 * CMake dummy - unused
 */

static int unused_1431423134;
