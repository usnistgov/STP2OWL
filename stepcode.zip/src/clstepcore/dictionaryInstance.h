#ifndef DICTIONARYINSTANCE_H
#define DICTIONARYINSTANCE_H

#include "sc_export.h"

class SC_CORE_EXPORT Dictionary_instance
{

    protected:
        Dictionary_instance() {}
        Dictionary_instance(const Dictionary_instance &) {}

        virtual ~Dictionary_instance() {};
};


#endif //DICTIONARYINSTANCE_H
